class A{
	public A() {
	
        System.out.println("in A ");
        
	}
	public A(int i) {
		System.out.println("in A in");
	}
}
class B extends A{
	public B() {
		 super();
	   System.out.println("in B");
	} 
	public B(int i) {
	     this();
		System.out.println("in B in");
	}
}
public class Project1 {
	public static void main(String[] args) {
	
	    A obj1= new A(5);
		B obj=new B(5);
		
	}
}

